# Calorie-Counter-App
This is a calorie counter app made with Django.
Details can be found from my [blog](https://medium.com/dev-genius/calorie-tracker-app-with-python-django-framework-cc86dc2046e8) 
